import { useState, useEffect } from "react";
import { SwasthSplash } from "@/components/SwasthSplash";
import { AuthScreen } from "@/components/AuthScreen";
import { ProfileScreen } from "@/components/ProfileScreen";
import { Dashboard } from "@/components/Dashboard";
import { SymptomChecker } from "@/components/SymptomChecker";
import { BottomNavigation } from "@/components/BottomNavigation";

type Screen = 'splash' | 'auth' | 'profile' | 'dashboard' | 'symptoms';

interface UserData {
  id: string;
  name: string;
  age: string;
  gender: string;
  phone: string;
  stateOfOrigin: string;
  aadhaarWorkerID?: string;
  bloodGroup?: string;
}

const Index = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [userData, setUserData] = useState<UserData | null>(null);

  useEffect(() => {
    // Check if user is already logged in
    const existingUser = localStorage.getItem('swasthUser');
    if (existingUser) {
      setUserData(JSON.parse(existingUser));
      setCurrentScreen('dashboard');
    }
  }, []);

  const handleGetStarted = () => {
    setCurrentScreen('auth');
  };

  const handleAuthSuccess = (user: UserData) => {
    setUserData(user);
    setCurrentScreen('profile');
  };

  const handleGoToDashboard = () => {
    setCurrentScreen('dashboard');
  };

  const handleBackToSplash = () => {
    setCurrentScreen('splash');
  };

  const handleBackToAuth = () => {
    setCurrentScreen('auth');
  };

  const handleBackToProfile = () => {
    setCurrentScreen('profile');
  };

  const handleTabChange = (tab: string) => {
    if (!userData && tab !== 'register') {
      setCurrentScreen('auth');
      return;
    }

    switch (tab) {
      case 'register':
        setCurrentScreen('auth');
        break;
      case 'health':
      case 'qr':
      case 'upload':
        setCurrentScreen('dashboard');
        break;
      case 'symptoms':
        setCurrentScreen('symptoms');
        break;
      default:
        setCurrentScreen('dashboard');
    }
  };

  const showBottomNav = currentScreen !== 'splash' && currentScreen !== 'profile';
  const getActiveTab = () => {
    switch (currentScreen) {
      case 'auth': return 'register';
      case 'symptoms': return 'symptoms';
      case 'dashboard': return 'health';
      default: return 'health';
    }
  };

  return (
    <div className="max-w-md mx-auto min-h-screen bg-background relative">
      {currentScreen === 'splash' && (
        <SwasthSplash onGetStarted={handleGetStarted} />
      )}
      
      {currentScreen === 'auth' && (
        <AuthScreen 
          onBack={handleBackToSplash}
          onAuthSuccess={handleAuthSuccess}
        />
      )}
      
      {currentScreen === 'profile' && userData && (
        <ProfileScreen 
          userData={userData}
          onBack={handleBackToAuth}
          onGoToDashboard={handleGoToDashboard}
        />
      )}
      
      {currentScreen === 'dashboard' && userData && (
        <Dashboard 
          userData={userData}
          onBack={handleBackToProfile}
        />
      )}

      {currentScreen === 'symptoms' && (
        <SymptomChecker 
          onBack={() => setCurrentScreen('dashboard')}
        />
      )}

      {showBottomNav && (
        <BottomNavigation 
          activeTab={getActiveTab()}
          onTabChange={handleTabChange}
        />
      )}
    </div>
  );
};

export default Index;
