import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, QrCode, Download, ArrowRight, Copy, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface UserData {
  id: string;
  name: string;
  age: string;
  gender: string;
  phone: string;
  stateOfOrigin: string;
  aadhaarWorkerID?: string;
  bloodGroup?: string;
}

interface ProfileScreenProps {
  userData: UserData;
  onBack: () => void;
  onGoToDashboard: () => void;
}

export const ProfileScreen = ({ userData, onBack, onGoToDashboard }: ProfileScreenProps) => {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const handleCopyId = async () => {
    try {
      await navigator.clipboard.writeText(userData.id);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "Worker ID copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Error",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleDownloadQR = () => {
    // Create QR code data URL
    const qrData = `https://swasth.id/worker/${userData.id}`;
    
    // Create canvas for QR code
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 300;
    canvas.height = 300;
    
    if (ctx) {
      // Simple QR code representation (in real app, use proper QR library)
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, 300, 300);
      ctx.fillStyle = '#000000';
      ctx.font = '12px monospace';
      ctx.fillText('QR Code for:', 10, 20);
      ctx.fillText(userData.id, 10, 40);
      
      // Create download link
      const link = document.createElement('a');
      link.download = `swasth-qr-${userData.id}.png`;
      link.href = canvas.toDataURL();
      link.click();
      
      toast({
        title: "Downloaded!",
        description: "QR code saved to your device",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col pb-20">
      {/* Header */}
      <div className="bg-gradient-header text-white px-6 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">My SwasthID</h1>
          <p className="text-blue-100">Your Digital Health ID</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-6">
        <Card className="shadow-card">
          <CardContent className="p-8 text-center space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-2">{userData.name}</h2>
              <p className="text-muted-foreground">
                Age: {userData.age} | {userData.gender.charAt(0).toUpperCase() + userData.gender.slice(1)}
              </p>
              <p className="text-muted-foreground">
                From: {userData.stateOfOrigin}
              </p>
            </div>
            
            <div className="inline-block px-4 py-2 bg-primary/10 rounded-lg">
              <p className="text-sm text-primary font-medium mb-1">ID: {userData.id}</p>
            </div>
            
            <div className="flex justify-center">
              <div className="w-48 h-48 bg-muted rounded-lg flex flex-col items-center justify-center border-2 border-border">
                <QrCode className="w-20 h-20 text-foreground mb-2" />
                <span className="text-xs text-muted-foreground">QR CODE</span>
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground px-4">
              Show this QR code to healthcare providers for instant access to your health records
            </p>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            Registered on: {new Date().toLocaleDateString('en-GB')}
          </p>
        </div>
      </div>
    </div>
  );
};