import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  User, 
  FileText, 
  Plus, 
  Syringe, 
  Heart, 
  Calendar,
  ArrowLeft,
  Stethoscope
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface UserData {
  id: string;
  name: string;
  age: string;
  gender: string;
  phone: string;
  bloodGroup?: string;
}

interface MedicalRecord {
  id: string;
  type: 'prescription' | 'vaccination';
  doctorName?: string;
  description: string;
  date: string;
  vaccineName?: string;
}

interface DashboardProps {
  userData: UserData;
  onBack: () => void;
}

export const Dashboard = ({ userData, onBack }: DashboardProps) => {
  const [bloodGroup, setBloodGroup] = useState(userData.bloodGroup || '');
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [showAddRecord, setShowAddRecord] = useState(false);
  const [showAddVaccine, setShowAddVaccine] = useState(false);
  const [newRecord, setNewRecord] = useState({
    doctorName: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [newVaccine, setNewVaccine] = useState({
    vaccineName: '',
    date: new Date().toISOString().split('T')[0],
  });
  const { toast } = useToast();

  const handleBloodGroupUpdate = () => {
    const updatedUser = { ...userData, bloodGroup };
    localStorage.setItem('swasthUser', JSON.stringify(updatedUser));
    toast({
      title: "Updated!",
      description: "Blood group saved successfully",
    });
  };

  const handleAddRecord = () => {
    const record: MedicalRecord = {
      id: Date.now().toString(),
      type: 'prescription',
      doctorName: newRecord.doctorName,
      description: newRecord.description,
      date: newRecord.date,
    };
    
    setRecords(prev => [record, ...prev]);
    setNewRecord({ doctorName: '', description: '', date: new Date().toISOString().split('T')[0] });
    setShowAddRecord(false);
    
    toast({
      title: "Record Added!",
      description: "Medical record saved successfully",
    });
  };

  const handleAddVaccine = () => {
    const vaccine: MedicalRecord = {
      id: Date.now().toString(),
      type: 'vaccination',
      description: `${newVaccine.vaccineName} vaccination`,
      date: newVaccine.date,
      vaccineName: newVaccine.vaccineName,
    };
    
    setRecords(prev => [vaccine, ...prev]);
    setNewVaccine({ vaccineName: '', date: new Date().toISOString().split('T')[0] });
    setShowAddVaccine(false);
    
    toast({
      title: "Vaccination Added!",
      description: "Vaccination record saved successfully",
    });
  };

  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const commonVaccines = ['COVID-19', 'Hepatitis B', 'Tetanus', 'Influenza', 'Typhoid', 'DPT', 'BCG'];

  return (
    <div className="min-h-screen bg-gradient-card px-6 py-8">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-bold text-foreground ml-3">Health Dashboard</h1>
      </div>

      <div className="space-y-6">
        {/* Worker Details Card */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Worker Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p className="font-medium">{userData.name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Worker ID</p>
                <p className="font-mono text-sm">{userData.id}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Age</p>
                <p className="font-medium">{userData.age} years</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Gender</p>
                <p className="font-medium capitalize">{userData.gender}</p>
              </div>
            </div>
            
            {/* Blood Group Section */}
            <div className="border-t pt-4">
              <Label htmlFor="bloodGroup" className="flex items-center gap-2 mb-2">
                <Heart className="w-4 h-4 text-red-500" />
                Blood Group
              </Label>
              <div className="flex gap-2">
                <Select value={bloodGroup} onValueChange={setBloodGroup}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select blood group" />
                  </SelectTrigger>
                  <SelectContent>
                    {bloodGroups.map(group => (
                      <SelectItem key={group} value={group}>{group}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={handleBloodGroupUpdate} size="sm" variant="medical">
                  Save
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            onClick={() => setShowAddRecord(true)}
            className="h-20 flex-col gap-2"
          >
            <Plus className="w-6 h-6" />
            Add Record
          </Button>
          <Button 
            variant="outline" 
            onClick={() => setShowAddVaccine(true)}
            className="h-20 flex-col gap-2"
          >
            <Syringe className="w-6 h-6" />
            Add Vaccine
          </Button>
        </div>

        {/* Medical Records */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Medical Records
            </CardTitle>
          </CardHeader>
          <CardContent>
            {records.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Stethoscope className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No medical records yet</p>
                <p className="text-sm">Add your first record above</p>
              </div>
            ) : (
              <div className="space-y-3">
                {records.map(record => (
                  <div key={record.id} className="border rounded-lg p-3">
                    <div className="flex items-start justify-between mb-2">
                      <Badge variant={record.type === 'vaccination' ? 'secondary' : 'outline'}>
                        {record.type === 'vaccination' ? 'Vaccination' : 'Prescription'}
                      </Badge>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(record.date).toLocaleDateString()}
                      </span>
                    </div>
                    {record.doctorName && (
                      <p className="text-sm font-medium mb-1">Dr. {record.doctorName}</p>
                    )}
                    <p className="text-sm text-muted-foreground">{record.description}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add Record Modal */}
        {showAddRecord && (
          <Card className="shadow-card border-primary">
            <CardHeader>
              <CardTitle>Add Medical Record</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="doctorName">Doctor Name</Label>
                <Input
                  id="doctorName"
                  value={newRecord.doctorName}
                  onChange={(e) => setNewRecord(prev => ({ ...prev, doctorName: e.target.value }))}
                  placeholder="Enter doctor's name"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newRecord.description}
                  onChange={(e) => setNewRecord(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Enter prescription details, diagnosis, etc."
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="recordDate">Date</Label>
                <Input
                  id="recordDate"
                  type="date"
                  value={newRecord.date}
                  onChange={(e) => setNewRecord(prev => ({ ...prev, date: e.target.value }))}
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddRecord} className="flex-1">Add Record</Button>
                <Button variant="outline" onClick={() => setShowAddRecord(false)}>Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Add Vaccine Modal */}
        {showAddVaccine && (
          <Card className="shadow-card border-primary">
            <CardHeader>
              <CardTitle>Add Vaccination</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="vaccineName">Vaccine Name</Label>
                <Select 
                  value={newVaccine.vaccineName} 
                  onValueChange={(value) => setNewVaccine(prev => ({ ...prev, vaccineName: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select vaccine" />
                  </SelectTrigger>
                  <SelectContent>
                    {commonVaccines.map(vaccine => (
                      <SelectItem key={vaccine} value={vaccine}>{vaccine}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="vaccineDate">Date</Label>
                <Input
                  id="vaccineDate"
                  type="date"
                  value={newVaccine.date}
                  onChange={(e) => setNewVaccine(prev => ({ ...prev, date: e.target.value }))}
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddVaccine} className="flex-1">Add Vaccination</Button>
                <Button variant="outline" onClick={() => setShowAddVaccine(false)}>Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};