import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Heart, Shield, Users } from "lucide-react";
import swasthLogo from "@/assets/swasth-logo.png";

interface SwasthSplashProps {
  onGetStarted: () => void;
}

export const SwasthSplash = ({ onGetStarted }: SwasthSplashProps) => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-primary flex flex-col items-center justify-center px-6 py-8">
      <div className={`transition-all duration-700 transform ${loaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
        
        {/* Logo Section */}
        <div className="text-center mb-8">
          <div className="w-24 h-24 mx-auto mb-6 bg-white rounded-2xl shadow-primary flex items-center justify-center">
            <img src={swasthLogo} alt="Swasth ID" className="w-16 h-16 object-contain" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">Swasth ID</h1>
          <p className="text-xl text-white/90 font-medium">Your Health, Your Identity</p>
        </div>

        {/* Problem Statement Card */}
        <Card className="bg-white/95 backdrop-blur-sm shadow-primary p-6 mb-8 max-w-md">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <Users className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-foreground mb-1">For Migrant Workers</h3>
                <p className="text-sm text-muted-foreground">Millions lack proper health documentation when moving between states for work.</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <Shield className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-foreground mb-1">Secure & Portable</h3>
                <p className="text-sm text-muted-foreground">Digital health records that travel with you, accessible anywhere, anytime.</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <Heart className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-foreground mb-1">Better Healthcare</h3>
                <p className="text-sm text-muted-foreground">Quick access to medical history helps doctors provide better, faster treatment.</p>
              </div>
            </div>
          </div>
        </Card>

        {/* CTA Button */}
        <div className="text-center">
          <Button 
            variant="hero" 
            size="xl" 
            onClick={onGetStarted}
            className="w-full max-w-md"
          >
            Get Started
          </Button>
          <p className="text-white/70 text-sm mt-4">Free • Secure • Works Offline</p>
        </div>
      </div>
    </div>
  );
};