import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

interface AuthScreenProps {
  onBack: () => void;
  onAuthSuccess: (userData: UserData) => void;
}

interface UserData {
  id: string;
  name: string;
  age: string;
  gender: string;
  phone: string;
  stateOfOrigin: string;
  aadhaarWorkerID?: string;
  bloodGroup?: string;
}

export const AuthScreen = ({ onBack, onAuthSuccess }: AuthScreenProps) => {
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    phone: "",
    stateOfOrigin: "",
    aadhaarWorkerID: "",
  });
  const { toast } = useToast();

  const indianStates = [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
    "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
    "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
    "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
    "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
  ];

  const generateWorkerId = () => {
    return `SW${Date.now().toString().slice(-8)}${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const userData: UserData = {
      id: generateWorkerId(),
      name: formData.name,
      age: formData.age,
      gender: formData.gender,
      phone: formData.phone,
      stateOfOrigin: formData.stateOfOrigin,
      aadhaarWorkerID: formData.aadhaarWorkerID,
    };
    
    // Store user data in localStorage for demo
    localStorage.setItem('swasthUser', JSON.stringify(userData));
    
    toast({
      title: "Registration Successful!",
      description: `Your SwasthID: ${userData.id}`,
    });
    
    onAuthSuccess(userData);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col pb-20">
      {/* Header */}
      <div className="bg-gradient-header text-white px-6 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">SwasthID Kerala</h1>
          <p className="text-blue-100">Healthcare for Migrant Workers</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">
          Register for SwasthID
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name" className="text-foreground font-medium">
              Full Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter your full name"
              className="mt-1"
              required
            />
          </div>

          <div>
            <Label htmlFor="age" className="text-foreground font-medium">
              Age <span className="text-destructive">*</span>
            </Label>
            <Input
              id="age"
              type="number"
              value={formData.age}
              onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
              placeholder="Enter your age"
              className="mt-1"
              required
            />
          </div>

          <div>
            <Label htmlFor="gender" className="text-foreground font-medium">
              Gender <span className="text-destructive">*</span>
            </Label>
            <Select 
              value={formData.gender} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, gender: value }))}
              required
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select Gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="stateOfOrigin" className="text-foreground font-medium">
              State of Origin <span className="text-destructive">*</span>
            </Label>
            <Select 
              value={formData.stateOfOrigin} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, stateOfOrigin: value }))}
              required
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select State" />
              </SelectTrigger>
              <SelectContent>
                {indianStates.map((state) => (
                  <SelectItem key={state} value={state}>{state}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="aadhaarWorkerID" className="text-foreground font-medium">
              Aadhaar/Worker ID (Optional)
            </Label>
            <Input
              id="aadhaarWorkerID"
              value={formData.aadhaarWorkerID}
              onChange={(e) => setFormData(prev => ({ ...prev, aadhaarWorkerID: e.target.value }))}
              placeholder="Enter Aadhaar or Worker ID"
              className="mt-1"
            />
          </div>

          <Button 
            type="submit" 
            className="w-full bg-primary hover:bg-primary/90 text-white py-3 text-lg font-medium mt-8"
            size="lg"
          >
            Register & Generate SwasthID
          </Button>
        </form>
      </div>
    </div>
  );
};