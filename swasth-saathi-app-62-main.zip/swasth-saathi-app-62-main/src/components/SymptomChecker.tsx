import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Thermometer, Activity, Zap, User, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SymptomCheckerProps {
  onBack: () => void;
}

export const SymptomChecker = ({ onBack }: SymptomCheckerProps) => {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const { toast } = useToast();

  const symptoms = [
    { id: 'fever', label: 'Fever', icon: Thermometer, color: 'text-red-500' },
    { id: 'cough', label: 'Cough', icon: Activity, color: 'text-orange-500' },
    { id: 'fatigue', label: 'Fatigue', icon: Zap, color: 'text-purple-500' },
    { id: 'body-pain', label: 'Body Pain', icon: User, color: 'text-teal-500' },
  ];

  const toggleSymptom = (symptomId: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(symptomId)
        ? prev.filter(id => id !== symptomId)
        : [...prev, symptomId]
    );
  };

  const assessRisk = () => {
    if (selectedSymptoms.length === 0) {
      toast({
        title: "No symptoms selected",
        description: "Please select at least one symptom to assess risk level.",
        variant: "destructive",
      });
      return;
    }

    // Simple risk assessment logic
    let riskLevel = "Low";
    let recommendation = "Rest and stay hydrated. Monitor your symptoms.";

    if (selectedSymptoms.length >= 3) {
      riskLevel = "High";
      recommendation = "Consult a healthcare professional immediately.";
    } else if (selectedSymptoms.includes('fever') && selectedSymptoms.length >= 2) {
      riskLevel = "Medium";
      recommendation = "Consider consulting a doctor if symptoms persist.";
    }

    toast({
      title: `Risk Level: ${riskLevel}`,
      description: recommendation,
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col pb-20">
      {/* Header */}
      <div className="bg-gradient-header text-white px-6 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Symptom Checker</h1>
          <p className="text-blue-100">AI-Powered Risk Assessment</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-6">
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-foreground mb-2">
            Select Your Symptoms
          </h2>
          <p className="text-muted-foreground">
            Choose all symptoms you are currently experiencing
          </p>
        </div>

        {/* Symptoms Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {symptoms.map(({ id, label, icon: Icon, color }) => (
            <Card 
              key={id}
              className={`cursor-pointer transition-all duration-200 ${
                selectedSymptoms.includes(id) 
                  ? 'ring-2 ring-primary bg-accent' 
                  : 'hover:shadow-md'
              }`}
              onClick={() => toggleSymptom(id)}
            >
              <CardContent className="p-6 text-center">
                <Icon className={`w-8 h-8 mx-auto mb-3 ${color}`} />
                <span className="font-medium text-foreground">{label}</span>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Assess Button */}
        <Button 
          onClick={assessRisk}
          className="w-full mb-6 bg-gray-500 hover:bg-gray-600 text-white py-3 text-lg"
          size="lg"
        >
          <Activity className="w-5 h-5 mr-2" />
          Assess Risk Level
        </Button>

        {/* Medical Disclaimer */}
        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-yellow-800 mb-1">Medical Disclaimer</h3>
                <p className="text-sm text-yellow-700">
                  This is a demo symptom checker for educational purposes only. 
                  Always consult qualified healthcare professionals for proper 
                  medical diagnosis and treatment.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};