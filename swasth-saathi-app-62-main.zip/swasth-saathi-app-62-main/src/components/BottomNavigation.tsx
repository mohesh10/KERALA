import { User, FileText, QrCode, Upload, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const BottomNavigation = ({ activeTab, onTabChange }: BottomNavigationProps) => {
  const tabs = [
    { id: 'register', label: 'Register', icon: User },
    { id: 'health', label: 'Health Rec.', icon: FileText },
    { id: 'qr', label: 'My QR', icon: QrCode },
    { id: 'upload', label: 'Upload', icon: Upload },
    { id: 'symptoms', label: 'Symptoms', icon: Activity },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
      <div className="max-w-md mx-auto">
        <div className="flex justify-around items-center py-2">
          {tabs.map(({ id, label, icon: Icon }) => (
            <Button
              key={id}
              variant="ghost"
              size="sm"
              onClick={() => onTabChange(id)}
              className={`flex flex-col items-center gap-1 px-2 py-2 h-auto ${
                activeTab === id 
                  ? 'text-primary' 
                  : 'text-muted-foreground'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-xs">{label}</span>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};